// empty file - just to keep p_256_multprecision.h without changes

#if defined(__ANDROID__)
typedef unsigned int DWORD;
#else
typedef unsigned long DWORD;
#endif
