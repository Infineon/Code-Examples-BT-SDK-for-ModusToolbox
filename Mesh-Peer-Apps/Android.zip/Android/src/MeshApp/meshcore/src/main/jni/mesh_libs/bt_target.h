
#include <stdio.h> 
#include <string.h> 

#include "platform.h"

#include "ccm.h"
#include "ecdh.h"

#define SMP_LE_SC_INCLUDED TRUE
