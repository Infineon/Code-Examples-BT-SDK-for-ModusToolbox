/*
 * Copyright Cypress Semiconductor
 */

/** @file
 *
 * Start of the iOS app view controller implementation.
 */

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

